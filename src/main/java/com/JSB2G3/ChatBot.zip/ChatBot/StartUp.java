package com.JSB2G3.ChatBot;

import java.util.*;

public class StartUp {
    //List<String> typesOfMonitors;
    List<String> greetings;

    Map<String,List<String>> monitors = new HashMap<String, List<String>>();
    Map<String,List<String>> monitorsFeatures= new HashMap<String, List<String>>();

    //modelName = {"Screen Size","Touch Screen","Pressure","eTCO2"}

    //Goldway Monitors
    private String[] goldway = {"G30E","G40E"};
    private String[] G30E = {"10","no","Type1/Type2","Mainstream"};
    private String[] G40E = {"12","no","Type1/Type2","Mainstream"};

    //Efficia Monitoirs
    private String[] efficia = {"CM10","CM12","CM100","CM120","CM150"};
    private String[] CM10 = {"10","no","Type1/Type2","Mainstream/Microstream"};
    private String[] CM12 = {"12","no","Type1/Type2","Mainstream/Microstream"};
    private String[] CM100 = {"10","yes","Type1/Type2/Type3/Type4","Mainstream/Microstream"};
    private String[] CM120 = {"12","yes","Type1/Type2/Type3/Type4","Mainstream/Microstream"};
    private String[] CM150 = {"15","yes","Type1/Type2/Type3/Type4","Mainstream/Microstream"};

    public StartUp()
    {
        //typesOfMonitors = Arrays.asList("IntelliVue Monitors", "Efficia Monitors","Goldway");
        greetings = Arrays.asList("Hello", "Hi from Philips", "Hey there friend!", "Greetings from Philips", "Welcome to Philips");


        monitors.put("Goldway", Arrays.asList(goldway));
        monitors.put("Efficia",Arrays.asList(efficia));


        monitorsFeatures.put("G30E",Arrays.asList(G30E));
        monitorsFeatures.put("G40E",Arrays.asList(G40E));
        monitorsFeatures.put("CM10",Arrays.asList(CM10));
        monitorsFeatures.put("CM12",Arrays.asList(CM12));
        monitorsFeatures.put("CM100",Arrays.asList(CM100));
        monitorsFeatures.put("CM120",Arrays.asList(CM120));
        monitorsFeatures.put("CM150",Arrays.asList(CM150));

     }

    public List<String> getMonitorsFeatures(String model) {
        return monitorsFeatures.get(model);
    }
    
    public List<String> getMonitorsList()
    {
        List<String> MonitorsList = new ArrayList<String>();
        for (String k : monitorsFeatures.keySet())
        {
            MonitorsList.add(k);
        }
        return MonitorsList;                
    }
}
