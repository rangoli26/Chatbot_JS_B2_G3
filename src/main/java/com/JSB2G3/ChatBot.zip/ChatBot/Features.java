package com.JSB2G3.ChatBot;

import java.util.ArrayList;
import java.util.List;

public class Features {

    List<String> Models;
    StartUp obj;

    public Features()
    {
        obj = new StartUp();
        Models = obj.getMonitorsList();
    }

    public List<String> getModelsBySize(String size, List<String> inputs)
    {
        if(inputs==null)
        {
            inputs=Models;
        }
        List<String> output= new ArrayList<>();
        String screenSize="";
        for(int i=0;i<inputs.size();i++)
        {
            screenSize = obj.getMonitorsFeatures(inputs.get(i)).get(0);
            if(screenSize.equals(size))
            {
                output.add(inputs.get(i));
            }
        }
        return output;
    }

    public List<String> getModelsByTouchScreen(String type, List<String> inputs)
    {
        if(inputs==null)
        {
            inputs=Models;
        }
        List<String> output= new ArrayList<>();
        String screenSize="";
        for(int i=0;i<inputs.size();i++)
        {
            screenSize = obj.getMonitorsFeatures(inputs.get(i)).get(1);
            if(screenSize.equals(type))
            {
                output.add(inputs.get(i));
            }
        }
        return output;
    }

}
