package com.JSB2G3.ChatBot;

import java.util.List;

public class ChatBot {
    public static void main(String[] args)
    {
        StartUp obj=new StartUp();
        System.out.println(obj.getMonitorsFeatures("G30E"));
        List<String> abc = obj.getMonitorsList();
        Features features =new Features();
        features.getModelsByTouchScreen("yes",null);

    }

}
